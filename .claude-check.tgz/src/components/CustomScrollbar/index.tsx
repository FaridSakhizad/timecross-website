export { default } from './CustomScrollbar';

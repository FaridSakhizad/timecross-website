import './style.css';

import { useEffect, useRef, useState } from 'react';
import { Link, useLocation } from 'react-router';

import { SITE_NAME, BUY_ME_A_COFFEE_URL } from '../../config';
import { SUPPORTED_LANGUAGES, useI18n } from '../../i18n';
import {
  getCanonicalLanguagePath,
  getLocalizedPathname,
} from '../../i18n/languageRouting';
import { SHORT_LANGUAGE_NAMES } from '../../i18n/languageLabels';
import type { ColorMode, TimeFormat } from '../../settings';
import StandaloneMenuModal from '../StandaloneMenuModal';

type HeaderProps = {
  customClassNames?: string;
  colorMode: ColorMode;
  timeFormat: TimeFormat;
  onColorModeButtonClick: () => void;
  onTimeFormatButtonClick: () => void;
};

export default function Header({
  customClassNames,
  colorMode,
  timeFormat,
  onColorModeButtonClick,
  onTimeFormatButtonClick,
}: HeaderProps) {
  const [isLangSelectorVisible, setIsLangSelectorVisible] = useState(false);
  const [isMenuModalOpen, setIsMenuModalOpen] = useState(false);
  const langSelectorRef = useRef<HTMLDivElement>(null);
  const { language, t } = useI18n();
  const location = useLocation();

  useEffect(() => {
    if (!isLangSelectorVisible) {
      return undefined;
    }

    const handleDocumentPointerDown = (event: PointerEvent) => {
      const target = event.target;

      if (
        target instanceof Node
        && !langSelectorRef.current?.contains(target)
      ) {
        setIsLangSelectorVisible(false);
      }
    };

    document.addEventListener('pointerdown', handleDocumentPointerDown);

    return () => {
      document.removeEventListener('pointerdown', handleDocumentPointerDown);
    };
  }, [isLangSelectorVisible]);

  const handleLangSelectorClick = () => {
    setIsLangSelectorVisible((isVisible) => !isVisible);
  };

  return (
    <header className={['header', customClassNames].filter(Boolean).join(' ')}>
      <div className="container">
        <Link
          to={getCanonicalLanguagePath(language)}
          className="logo"
          title={`${SITE_NAME} | Prod`}
        >
          <span className="logo-name">{SITE_NAME}</span>
          <span className="logo-pitch">{t('common.sitePitch')}</span>
        </Link>

        <div className="headerMenu">
          <a
            href={BUY_ME_A_COFFEE_URL}
            className="headerMenu-item headerMenu-item_thanks"
            target="_blank"
          >
            {t('common.sayThanks')}
          </a>

          <i className="headerMenu-separator headerMenu-separator_1" />

          <Link
            to={getCanonicalLanguagePath(language, '/cities')}
            className="headerMenu-item headerMenu-item_link"
          >
            {t('common.citiesLabel')}
          </Link>

          <Link
            to={getCanonicalLanguagePath(language, '/grid')}
            className="headerMenu-item headerMenu-item_link"
          >
            {t('common.gridLabel')}
          </Link>

          <Link
            to={getCanonicalLanguagePath(language, '/convert')}
            className="headerMenu-item headerMenu-item_link"
          >
            {t('common.timeZoneConverterLabel')}
          </Link>

          <i className="headerMenu-separator headerMenu-separator_2" />

          <button
            type="button"
            className="headerMenu-item headerMenu-item_ampm"
            onClick={onTimeFormatButtonClick}
          >
            {timeFormat === '24h' ? 'AM/PM' : '24H'}
          </button>

          <button
            type="button"
            className={`headerMenu-item headerMenu-item_nightMode ${colorMode === 'night' ? 'isActive' : ''}`}
            aria-label={t(colorMode === 'night' ? 'common.lightMode' : 'common.darkMode')}
            onClick={onColorModeButtonClick}
          />

          <div
            className="langSelectButtonBox"
            ref={langSelectorRef}
          >
            <button
              type="button"
              className="headerMenu-item langSelectButton"
              onClick={handleLangSelectorClick}
            >
              <span className="langSelectButton-shortName">{SHORT_LANGUAGE_NAMES[language]}</span>
            </button>

            {isLangSelectorVisible && (
              <div className="langSelectMenu">
                {SUPPORTED_LANGUAGES.filter((languageOption) => languageOption !== language).map((languageOption) => (
                  <Link
                    to={getLocalizedPathname(location.pathname, languageOption)}
                    className="langSelectMenu-button"
                    key={languageOption}
                    onClick={() => setIsLangSelectorVisible(false)}
                  >
                    {t(`languages.${languageOption}`)}
                  </Link>
                ))}
              </div>
            )}
          </div>

          <button
            type="button"
            className="headerMenu-item headerMenu-item_menu"
            aria-label={t('common.menu')}
            aria-haspopup="dialog"
            aria-expanded={isMenuModalOpen}
            onClick={() => {
              setIsLangSelectorVisible(false);
              setIsMenuModalOpen(true);
            }}
          />
        </div>
      </div>
      <StandaloneMenuModal
        colorMode={colorMode}
        timeFormat={timeFormat}
        isOpen={isMenuModalOpen}
        onClose={() => setIsMenuModalOpen(false)}
        onColorModeButtonClick={onColorModeButtonClick}
        onTimeFormatButtonClick={onTimeFormatButtonClick}
      />
    </header>
  );
}

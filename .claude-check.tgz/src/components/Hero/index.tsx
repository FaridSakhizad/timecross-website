export { default } from './Hero';

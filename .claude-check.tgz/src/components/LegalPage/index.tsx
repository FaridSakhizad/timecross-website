export { default } from './LegalPage';

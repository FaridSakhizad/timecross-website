export { default } from './Seo';

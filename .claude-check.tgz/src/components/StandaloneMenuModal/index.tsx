export { default } from './StandaloneMenuModal';

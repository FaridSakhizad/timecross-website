import { memo, useEffect, useState } from 'react';
import { useSortable } from '@dnd-kit/sortable';
import { CSS } from '@dnd-kit/utilities';

import { useI18n } from '../../../i18n';
import { getIntlLocale } from '../../../i18n/intlLocale';
import type { TimeFormat } from '../../../settings';
import type { StoredCity } from '../../../settings';
import { getCityDisplayName } from '../../Cities/useLocalizedCities';
import TimelineCellLabel from '../../Timelines/TimelineCellLabel';
import {
  formatTime,
  getRelativeDayMarker,
  getTimelineCells,
} from '../../Timelines/utils';
import { formatRelativeOffset, getTimeZoneOffsetMinutes } from '../../../utils/time';
import { gridHourKey } from './gridSelection';

export type GridRowClasses = { row?: string; city?: string; cells: string; spacer: string };

type TimelineGridRowProps = {
  baseDate: Date;
  browserTimezone: string;
  city: StoredCity;
  isEditMode: boolean;
  classNames: GridRowClasses;
  timelineDates: Date[];
  timeFormat: TimeFormat;
  onDelete: (cityId: string) => void;
  selectedHourKeys?: ReadonlySet<string>;
};

function isTimelineGridDragPressTarget(target: EventTarget | null) {
  return target instanceof Element
    && Boolean(target.closest('.timelineGrid-dragButton, .timelineGrid-cellsSpacer'));
}

function TimelineGridRow({
  baseDate,
  browserTimezone,
  city,
  isEditMode,
  classNames,
  timelineDates,
  timeFormat,
  onDelete,
  selectedHourKeys,
}: TimelineGridRowProps) {
  const { language, t } = useI18n();
  const [isPressed, setIsPressed] = useState(false);
  const displayName = getCityDisplayName(city);
  const shouldRenderCells = !isEditMode;
  const cells = shouldRenderCells
    ? getTimelineCells(city.timezone, baseDate, timelineDates, timeFormat, getIntlLocale(language))
    : [];
  const offsetMinutes = getTimeZoneOffsetMinutes(city.timezone, baseDate)
    - getTimeZoneOffsetMinutes(browserTimezone, baseDate);
  const offset = formatRelativeOffset(offsetMinutes, t('cities.sameOffset'));
  const relativeDayMarker = getRelativeDayMarker(city.timezone, browserTimezone, baseDate);
  const {
    attributes,
    listeners,
    setNodeRef,
    transform,
    transition,
    isDragging,
  } = useSortable({
    id: city.id,
    disabled: !isEditMode,
  });
  const verticalTransform = transform ? { ...transform, x: 0 } : null;
  const style = {
    transform: CSS.Transform.toString(verticalTransform),
    transition,
  };
  const handlePressStart = (target: EventTarget | null) => {
    if (!isEditMode || !isTimelineGridDragPressTarget(target)) {
      return;
    }

    setIsPressed(true);
  };

  useEffect(() => {
    if (!isPressed) {
      return undefined;
    }

    const handlePressEnd = () => setIsPressed(false);

    window.addEventListener('pointerup', handlePressEnd);
    window.addEventListener('pointercancel', handlePressEnd);
    window.addEventListener('touchend', handlePressEnd);
    window.addEventListener('touchcancel', handlePressEnd);

    return () => {
      window.removeEventListener('pointerup', handlePressEnd);
      window.removeEventListener('pointercancel', handlePressEnd);
      window.removeEventListener('touchend', handlePressEnd);
      window.removeEventListener('touchcancel', handlePressEnd);
    };
  }, [isPressed]);

  return (
    <div
      className={[
        'timelineGrid-row',
        classNames.row,
        isEditMode ? 'timelineGrid-row_reorder' : '',
        isEditMode && isPressed && !isDragging ? 'timelineGrid-row_pressed' : '',
        isDragging ? 'timelineGrid-row_dragging' : '',
      ].filter(Boolean).join(' ')}
      onPointerDown={(event) => handlePressStart(event.target)}
      onTouchStart={(event) => handlePressStart(event.target)}
      ref={setNodeRef}
      style={style}
    >
      <div className={['timelineGrid-city', classNames.city].filter(Boolean).join(' ')}>
        <div className="timelineGrid-cityInner">
          {isEditMode && (
            <button
              className="timelineGrid-dragButton"
              type="button"
              aria-label={t('cities.moveCity', { city: displayName })}
              {...attributes}
              {...listeners}
            />
          )}

          <span className="timelineGrid-cityName">
            {`${displayName}, `}
            <span className="timelineGrid-cityOffset">{offset}</span>
          </span>

          {/* eslint-disable-next-line */}
          {(false && relativeDayMarker) && (
            <span className={`timelineGrid-dayMarker timelineGrid-dayMarker_${relativeDayMarker}`}>
              {relativeDayMarker === 'tomorrow' ? t('cities.tomorrow') : t('cities.yesterday')}
            </span>
          )}

          <span className="timelineGrid-cityTime">{formatTime(baseDate, city.timezone, timeFormat)}</span>

          {isEditMode && (
            <button
              className="timelineGrid-deleteButton"
              type="button"
              aria-label={t('cities.deleteCity', { city: displayName })}
              onClick={() => onDelete(city.id)}
            />
          )}
        </div>
      </div>

      {shouldRenderCells && (
        <div className={`timelineGrid-cells ${classNames.cells}`}>
          {cells.map((cell, index) => {
            const shouldShowFullCurrentTime = cell.isCurrentHour && Boolean(cell.dateCellDetails);

            return (
              <span
                className={[
                  'timelineGrid-cell',
                  `timelineGrid-cell_${cell.period}`,
                  cell.isAdjacentDay ? 'timelineGrid-cell_adjacentDay' : '',
                  cell.isCurrentHour ? 'timelineGrid-cell_current' : '',
                  cell.isDateLabel ? 'timelineGrid-cell_date' : '',
                  shouldShowFullCurrentTime ? 'timelineGrid-cell_fullTime' : '',
                  selectedHourKeys?.has(gridHourKey({ rowId: city.id, start: cell.date.getTime() })) ? 'isSelected' : '',
                ].filter(Boolean).join(' ')}
                key={`${city.id}-${cell.date.toISOString()}-${index}`}
                data-grid-selection-row={city.id}
                data-grid-hour-start={cell.date.getTime()}
              >
                {cell.dateCellDetails
                  ? (
                      <span className="timelineGrid-cellDateDetails">
                        <span className="timelineGrid-cellDateWeekday">
                          {cell.dateCellDetails.weekdayLabel}
                        </span>
                        <span className="timelineGrid-cellDateDay">
                          {cell.dateCellDetails.dateLabel}
                        </span>
                      </span>
                    )
                  : (
                      <TimelineCellLabel
                        label={cell.label}
                        period={cell.isCurrentHour ? null : cell.labelPeriod}
                        periodClassName="timelineGrid-periodMarker"
                      />
                    )}
                {shouldShowFullCurrentTime && (
                  <span className="timelineGrid-cellCurrentTime">
                    <span className="timelineGrid-cellCurrentMinutes">{cell.currentTimeLabel}</span>
                    {cell.periodLabel && (
                      <span className="timelineGrid-cellCurrentPeriod">{cell.periodLabel}</span>
                    )}
                  </span>
                )}
                {cell.isCurrentHour && !shouldShowFullCurrentTime && (
                  <span className="timelineGrid-cellCurrentTime">
                    <span className="timelineGrid-cellCurrentMinutes">{cell.minuteLabel}</span>
                    {cell.periodLabel && (
                      <span className="timelineGrid-cellCurrentPeriod">{cell.periodLabel}</span>
                    )}
                  </span>
                )}
              </span>
            );
          })}
        </div>
      )}

      {!shouldRenderCells && (
        <div
          className={`timelineGrid-cellsSpacer ${classNames.spacer}`}
          aria-label={t('cities.moveCity', { city: displayName })}
          style={{
            width: `calc(${timelineDates.length} * var(--timeline-grid-hour-width))`,
          }}
          {...attributes}
          {...listeners}
        />
      )}
    </div>
  );
}

export default memo(TimelineGridRow);

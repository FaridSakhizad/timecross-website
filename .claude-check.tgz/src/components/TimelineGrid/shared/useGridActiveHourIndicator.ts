import { useCallback, useEffect, useState } from 'react';

type TimelineGridScrollTarget = | { type: 'page' }
  | { type: 'element'; element: HTMLDivElement };

export type TimelineGridActiveHourDirection = 'left' | 'right' | null;

const ACTIVE_HOUR_VISIBILITY_PADDING = 8;

function getTimelineGridRoot(scrollTarget: TimelineGridScrollTarget) {
  return scrollTarget.type === 'page' ? document : scrollTarget.element;
}

function getTimelineGridActiveHour(scrollTarget: TimelineGridScrollTarget) {
  return getTimelineGridRoot(scrollTarget)
    .querySelector<HTMLElement>('.timelineGrid-userHours .timelineGrid-hour_current');
}

function getTimelineGridSnapTargets(scrollTarget: TimelineGridScrollTarget) {
  const firstCellsRow = getTimelineGridRoot(scrollTarget).querySelector<HTMLElement>('.timelineGrid-cells');

  return firstCellsRow
    ? Array.from(firstCellsRow.querySelectorAll<HTMLElement>('.timelineGrid-cell'))
    : [];
}

function getTimelineGridActiveSnapTarget(scrollTarget: TimelineGridScrollTarget) {
  return getTimelineGridRoot(scrollTarget)
    .querySelector<HTMLElement>('.timelineGrid-cells .timelineGrid-cell_current');
}

function getElementActiveHourDirection(
  element: HTMLDivElement,
  activeHour: HTMLElement,
): TimelineGridActiveHourDirection {
  const activeHourLeft = activeHour.offsetLeft;
  const activeHourRight = activeHourLeft + activeHour.offsetWidth;
  const viewportLeft = element.scrollLeft + ACTIVE_HOUR_VISIBILITY_PADDING;
  const viewportRight = element.scrollLeft + element.clientWidth - ACTIVE_HOUR_VISIBILITY_PADDING;

  if (activeHourRight < viewportLeft) {
    return 'left';
  }

  if (activeHourLeft > viewportRight) {
    return 'right';
  }

  return null;
}

function getPageActiveHourDirection(activeHour: HTMLElement): TimelineGridActiveHourDirection {
  const activeHourRect = activeHour.getBoundingClientRect();
  const viewportLeft = ACTIVE_HOUR_VISIBILITY_PADDING;
  const viewportRight = window.innerWidth - ACTIVE_HOUR_VISIBILITY_PADDING;

  if (activeHourRect.right < viewportLeft) {
    return 'left';
  }

  if (activeHourRect.left > viewportRight) {
    return 'right';
  }

  return null;
}

function getTimelineGridActiveHourDirection(
  scrollTarget: TimelineGridScrollTarget,
): TimelineGridActiveHourDirection {
  const activeHour = getTimelineGridActiveHour(scrollTarget);

  if (!activeHour) {
    return null;
  }

  return scrollTarget.type === 'page'
    ? getPageActiveHourDirection(activeHour)
    : getElementActiveHourDirection(scrollTarget.element, activeHour);
}

function getSnapTargetDocumentCenter(target: HTMLElement) {
  const targetRect = target.getBoundingClientRect();

  return window.scrollX + targetRect.left + targetRect.width / 2;
}

function getSnapTargetElementCenter(target: HTMLElement) {
  return target.offsetLeft + target.offsetWidth / 2;
}

function getSnapStep(targets: HTMLElement[]) {
  if (targets.length < 2) {
    return targets[0]?.offsetWidth || 1;
  }

  return Math.max(1, Math.abs(targets[1].offsetLeft - targets[0].offsetLeft));
}

function getEdgeTargetIndex(
  targets: HTMLElement[],
  activeTargetIndex: number,
  viewportWidth: number,
  direction: Exclude<TimelineGridActiveHourDirection, null>,
) {
  const activeTarget = targets[activeTargetIndex];
  const step = getSnapStep(targets);
  const edgeDistance = Math.max(
    0,
    Math.floor((viewportWidth / 2 - activeTarget.offsetWidth / 2) / step),
  );
  const targetIndex = direction === 'left'
    ? activeTargetIndex + edgeDistance
    : activeTargetIndex - edgeDistance;

  return Math.max(0, Math.min(targets.length - 1, targetIndex));
}

function scrollTimelineGridActiveHourToEdge(
  scrollTarget: TimelineGridScrollTarget,
  direction: Exclude<TimelineGridActiveHourDirection, null>,
) {
  const targets = getTimelineGridSnapTargets(scrollTarget);
  const activeTarget = getTimelineGridActiveSnapTarget(scrollTarget);
  const activeTargetIndex = activeTarget ? targets.indexOf(activeTarget) : -1;

  if (activeTargetIndex < 0) {
    return;
  }

  const viewportWidth = scrollTarget.type === 'page'
    ? window.innerWidth
    : scrollTarget.element.clientWidth;
  const target = targets[getEdgeTargetIndex(targets, activeTargetIndex, viewportWidth, direction)];
  const targetScrollLeft = scrollTarget.type === 'page'
    ? getSnapTargetDocumentCenter(target) - window.innerWidth / 2
    : getSnapTargetElementCenter(target) - scrollTarget.element.clientWidth / 2;

  if (scrollTarget.type === 'page') {
    document.scrollingElement?.scrollTo({
      left: targetScrollLeft,
      top: window.scrollY,
      behavior: 'smooth',
    });
    return;
  }

  scrollTarget.element.scrollTo({
    left: targetScrollLeft,
    top: scrollTarget.element.scrollTop,
    behavior: 'smooth',
  });
}

export function useTimelineGridActiveHourIndicator(
  getScrollTarget: () => TimelineGridScrollTarget | null,
  disabled = false,
) {
  const [direction, setDirection] = useState<TimelineGridActiveHourDirection>(null);

  const updateDirection = useCallback(() => {
    if (disabled) {
      return;
    }

    const scrollTarget = getScrollTarget();

    setDirection(scrollTarget ? getTimelineGridActiveHourDirection(scrollTarget) : null);
  }, [disabled, getScrollTarget]);

  useEffect(() => {
    if (disabled) {
      return undefined;
    }

    const scrollTarget = getScrollTarget();

    if (!scrollTarget) {
      return undefined;
    }

    const eventTarget = scrollTarget.type === 'page' ? window : scrollTarget.element;
    let animationFrame = 0;

    const scheduleUpdate = () => {
      if (animationFrame) {
        return;
      }

      animationFrame = window.requestAnimationFrame(() => {
        animationFrame = 0;
        updateDirection();
      });
    };

    eventTarget.addEventListener('scroll', scheduleUpdate, { passive: true });
    window.addEventListener('resize', scheduleUpdate);
    scheduleUpdate();

    return () => {
      eventTarget.removeEventListener('scroll', scheduleUpdate);
      window.removeEventListener('resize', scheduleUpdate);

      if (animationFrame) {
        window.cancelAnimationFrame(animationFrame);
      }
    };
  }, [disabled, getScrollTarget, updateDirection]);

  const scrollActiveHourIntoView = useCallback(() => {
    if (!direction) {
      return;
    }

    const scrollTarget = getScrollTarget();

    if (scrollTarget) {
      scrollTimelineGridActiveHourToEdge(scrollTarget, direction);
    }
  }, [direction, getScrollTarget]);

  return {
    direction: disabled ? null : direction,
    scrollActiveHourIntoView,
  };
}
